var React = require("react");
var ReactDOM = require("react-dom");

const daftarWarna = [
  "red", "blue", "green", "orange", "purple",
  "pink", "brown", "gray", "tomato", "seagreen", "gold"
];

function acakWarna() {
  const i = Math.floor(Math.random() * daftarWarna.length);
  return daftarWarna[i];
}

ReactDOM.render(
  <div>
    <h1 style={{ color: acakWarna() }}>Hello World</h1>
    <p style={{ color: acakWarna() }}>My Name is Muhammad Haikal Wibowo</p>
    <p style={{ color: acakWarna() }}>I am a handsome human being</p>
    <p style={{ color: acakWarna() }}>I love to learn JavaScript</p>
    <p style={{ color: acakWarna() }}>I am a super high quality student</p>
    <p style={{ color: acakWarna() }}>I am going to be a super star</p>
  </div>,
  document.getElementById("root")
);
